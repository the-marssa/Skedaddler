using TMPro;
using UnityEngine;

public class StatsPanelController : MonoBehaviour
{
    [Header("Lifetime totals (from save)")]
    [SerializeField] private TMP_Text totalStarsText;   
    [SerializeField] private TMP_Text totalLettersText; 

    [Header("Last run (runtime cache)")]
    [SerializeField] private TMP_Text lastScoreText;    
    [SerializeField] private TMP_Text lastStarsText;    
    [SerializeField] private TMP_Text lastLettersText;  
    [SerializeField] private TMP_Text lastDistanceText; 
    [SerializeField] private TMP_Text lastCpsText;      

    private void OnEnable()
    {
        
        var save = (StatsManager.Instance != null) ? StatsManager.Instance.Save : SaveSystem.LoadOrCreate();
        if (totalStarsText) totalStarsText.text = $"������: {save.lifetime.totalStars}";
        if (totalLettersText) totalLettersText.text = $"������: {save.lifetime.totalLetters}";

        
        RunSnapshot last = null;

        if (StatsManager.Instance != null)
        {
           
            if (StatsManager.Instance.CurrentRun != null)
                last = StatsManager.Instance.CurrentRun;
            
            else
                last = StatsManager.Instance.LastRunCached;
        }

        if (last != null)
        {
            if (lastScoreText) lastScoreText.text = $"����: {last.score}";
            if (lastStarsText) lastStarsText.text = $"ǳ���: {last.stars}";
            if (lastLettersText) lastLettersText.text = $"�����: {last.letters}";
            if (lastDistanceText) lastDistanceText.text = $"���������: {Mathf.FloorToInt(last.distance)} �";
            if (lastCpsText) lastCpsText.text = $"��������: {last.checkpointsReached}";
        }
        else
        {
           
            if (lastScoreText) lastScoreText.text = "����: �";
            if (lastStarsText) lastStarsText.text = "ǳ���: �";
            if (lastLettersText) lastLettersText.text = "�����: �";
            if (lastDistanceText) lastDistanceText.text = "���������: �";
            if (lastCpsText) lastCpsText.text = "��������: �";
        }
    }
}
